let mongodb = require("mongodb");
let talentsprint = mongodb.MongoClient;

let register  = require("express").Router().post("/",(req,res)=>{
        talentsprint.connect("mongodb://localhost:27017/crud",(err,db)=>
        {
            if(err){
                throw err;
            }   
            else{
                db.collection("viewer").insertOne({"firstName":req.body.firstName,"lastName":req.body.lastName,"email":req.body.email,"phoneNumber":req.body.phoneNumber,"password":req.body.password,"cpassword":req.body.cpassword},(err, result)=> {
                    if (err){
                        throw err;
                    }
                    res.send({message:"1 document inserted"});
                    db.close();
                  });
                }
            });
        });
module.exports = register;
